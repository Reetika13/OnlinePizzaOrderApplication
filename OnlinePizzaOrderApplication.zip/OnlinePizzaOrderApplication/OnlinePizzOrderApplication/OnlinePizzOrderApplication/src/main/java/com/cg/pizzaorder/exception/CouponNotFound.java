package com.cg.pizzaorder.exception;

public class CouponNotFound extends Exception{
	public CouponNotFound(String str) {
		super(str);
	}
}
