package com.cg.pizzaorder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.service.ICouponService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/odo-coupon")
public class CouponController {
	
	@Autowired
	ICouponService iCouponService;
	
	@PostMapping("/addCoupon")
	public Coupon addCoupon(@RequestBody Coupon coupon) throws Exception{
		return iCouponService.addCoupon(coupon);
	}
	
	@PutMapping("/editCoupon")
	public Coupon editCoupon(@RequestBody Coupon coupon) throws CouponNotFound{
		return iCouponService.editCoupon(coupon);
	}
	
	@DeleteMapping("/deleteCoupon")
	public Coupon deleteCoupon(@RequestBody Coupon coupon) throws CouponNotFound{
		return iCouponService.deleteCoupon(coupon);
	}
	
	@GetMapping("/viewCoupons")
	public List<Coupon> viewCoupons() throws Exception{
		return iCouponService.viewCoupons();
	}

}
