package com.cg.pizzaorder.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.pizzaorder.entity.PizzaOrder;

public interface IPizzaOrderService {
	
	public PizzaOrder bookPizzaOrder(PizzaOrder order) throws Exception;
	public PizzaOrder updatePizzaOrder(PizzaOrder order) throws Exception;
	public PizzaOrder cancelPizzaOrder(int bookingOrderId) throws Exception;
	public PizzaOrder viewPizzaOrder(int bookingOrderId) throws Exception;
	public List<PizzaOrder> viewOrdersList() throws Exception;
	public List<PizzaOrder> viewOrdersList(LocalDate date) throws Exception;
	public List<PizzaOrder> calculateTotal(String size,int quantity) throws Exception;
}
