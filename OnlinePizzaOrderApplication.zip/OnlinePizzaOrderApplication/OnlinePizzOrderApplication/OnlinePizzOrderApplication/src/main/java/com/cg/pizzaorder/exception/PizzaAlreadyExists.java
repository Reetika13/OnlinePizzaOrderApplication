package com.cg.pizzaorder.exception;

public class PizzaAlreadyExists  extends Exception{
	public PizzaAlreadyExists(String str) {
		super(str);
	}
}
