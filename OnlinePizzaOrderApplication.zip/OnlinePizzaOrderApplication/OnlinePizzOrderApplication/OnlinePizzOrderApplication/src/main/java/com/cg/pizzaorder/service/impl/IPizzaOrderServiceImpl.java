package com.cg.pizzaorder.service.impl;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.repository.IPizzaOrderRepository;
import com.cg.pizzaorder.service.IPizzaOrderService;

@Service("IPizzaOrderService")
public class IPizzaOrderServiceImpl implements IPizzaOrderService{
	
	@Autowired
	IPizzaOrderRepository iPizzaOrderRepository;

	@Override
	public PizzaOrder bookPizzaOrder(PizzaOrder order) throws Exception {
		iPizzaOrderRepository.saveAndFlush(order);
		return order;
	}

	@Override
	public PizzaOrder updatePizzaOrder(PizzaOrder order) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(order.getBookingOrderId()).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		iPizzaOrderRepository.saveAndFlush(order);
		return bean;
	}

	@Override
	public PizzaOrder cancelPizzaOrder(int bookingOrderId) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(bookingOrderId).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		iPizzaOrderRepository.deleteById(bookingOrderId);
		return bean;
	}

	@Override
	public PizzaOrder viewPizzaOrder(int bookingOrderId) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(bookingOrderId).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		return bean;
	}

	@Override
	public List<PizzaOrder> viewOrdersList() throws Exception {
		return iPizzaOrderRepository.findAll();
	}

	@Override
	public List<PizzaOrder> viewOrdersList(LocalDate date) throws Exception {
		List<PizzaOrder> ans = new ArrayList<PizzaOrder>();
		try {
			for(PizzaOrder i : iPizzaOrderRepository.findAll()) {
				if(i.getOrderDate() == date) {
					ans.add(i);
				}
			}
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		return ans;
	}

	@Override
	public List<PizzaOrder> calculateTotal(String size, int quantity) throws Exception {
		List<PizzaOrder> ans = new ArrayList<PizzaOrder>();
		try {
			for(PizzaOrder i : iPizzaOrderRepository.findAll()) {
				if(i.getSize().equals(size) && i.getQuantity() == quantity) {
					ans.add(i);
				}
			}
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		return ans;
	}
	

}
