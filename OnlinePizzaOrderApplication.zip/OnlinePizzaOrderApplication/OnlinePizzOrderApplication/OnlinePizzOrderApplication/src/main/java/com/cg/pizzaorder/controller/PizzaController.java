package com.cg.pizzaorder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.pizzaorder.entity.Pizza;
import com.cg.pizzaorder.service.IPizzaService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/odo-pizza")
public class PizzaController {
	
	@Autowired
	IPizzaService iPizzaService;
	
	@PostMapping("/addPizza")
	public Pizza addPizza(@RequestBody Pizza pizza) throws Exception{
		return iPizzaService.addPizza(pizza);
	}
	
	@PutMapping("/updatePizza")
	public Pizza updatePizza(@RequestBody Pizza pizza) throws Exception{
		return iPizzaService.updatePizza(pizza);
	}
	
	@DeleteMapping("/deletePizza/{pizzaId}")
	public Pizza deletePizza(@PathVariable int pizzaId) throws Exception{
		return iPizzaService.deletePizza(pizzaId);
	}
	
	@GetMapping("/viewPizzalist")
	public List<Pizza> viewPizzalist() throws Exception{
		return iPizzaService.viewPizzalist();
	}
	
	@GetMapping("/viewPizza/{pizzaId}")
	public Pizza viewPizza(@PathVariable int pizzaId) throws Exception{
		return iPizzaService.viewPizza(pizzaId);
	}
	
	@GetMapping("/viewPizzalist/{minCost}/{maxCost}")
	public List<Pizza> viewPizzalist(@PathVariable double minCost ,@PathVariable  double maxCost) throws Exception{
		return iPizzaService.viewPizzalist(minCost, maxCost);
	}
	
	@GetMapping("/viewPizzalist/{pizzaType}")
	public List<Pizza> viewPizzalist(@PathVariable String pizzaType) throws Exception{
		return iPizzaService.viewPizzalist(pizzaType);
	}

}

