package com.cg.pizzaorder.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.service.IPizzaOrderService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/odo-pizzaorder")
public class PizzaOrderController {
	
	@Autowired
	IPizzaOrderService iPizzaOrderService;
	
	@PostMapping("/bookPizzaOrder")
	public PizzaOrder bookPizzaOrder(@RequestBody PizzaOrder order) throws Exception{
		return iPizzaOrderService.bookPizzaOrder(order);
	}
	
	@PutMapping("/updatePizzaOrder")
	public PizzaOrder updatePizzaOrder(@RequestBody PizzaOrder order) throws Exception{
		return iPizzaOrderService.updatePizzaOrder(order);
	}
	
	@DeleteMapping("/cancelPizzaOrder/{bookingOrderId}")
	public PizzaOrder cancelPizzaOrder(@PathVariable int bookingOrderId) throws Exception{
		return iPizzaOrderService.cancelPizzaOrder(bookingOrderId);
	}
	
	@GetMapping("/viewPizzaOrder/{bookingOrderId}")
	public PizzaOrder viewPizzaOrder(@PathVariable int bookingOrderId) throws Exception{
		return iPizzaOrderService.viewPizzaOrder(bookingOrderId);
	}
	
	@GetMapping("/viewOrdersList")
	public List<PizzaOrder> viewOrdersList() throws Exception{
		return iPizzaOrderService.viewOrdersList();
	}
	
	@GetMapping("/viewOrdersList/{date}")
	public List<PizzaOrder> viewOrdersList(@PathVariable LocalDate date) throws Exception{
		return iPizzaOrderService.viewOrdersList(date);
	}
	
	@GetMapping("/calculateTotal/{size}/{quantity}")
	public List<PizzaOrder> calculateTotal(@PathVariable String size,@PathVariable int quantity) throws Exception{
		return iPizzaOrderService.calculateTotal(size, quantity);
	}
	
	
}

