package com.cg.pizzaorder.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.repository.ICustomerRepository;
import com.cg.pizzaorder.service.ICustomerService;

@Service("ICustomerService")
public class ICustomerServiceImpl implements ICustomerService{
	
	@Autowired 
	ICustomerRepository iCustomerRepository;

	@Override
	public Customer addCustomer(Customer customer) throws Exception {
		iCustomerRepository.saveAndFlush(customer);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) throws Exception {
		Customer  bean = null;
		try {
			bean = iCustomerRepository.findById(customer.getCustomerId()).get();
		}
		catch(Exception e) {
			throw new Exception("Customer details not found!");
		}
		iCustomerRepository.saveAndFlush(customer);
		return bean;
	}

	@Override
	public List<Customer> viewCustomers() throws Exception {
		return iCustomerRepository.findAll();
	}

	@Override
	public Customer viewCustomer(int customerId) throws Exception {
		Customer  bean = null;
		try {
			bean = iCustomerRepository.findById(customerId).get();
		}
		catch(Exception e) {
			throw new Exception("Customer details not found!");
		}
		return bean;
	}

}
