package com.cg.pizzaorder.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.repository.ICouponRepository;
import com.cg.pizzaorder.service.ICouponService;

@Service("ICouponService")
public class ICouponServiceImpl implements ICouponService{
	
	@Autowired
	ICouponRepository iCouponRepository;

	@Override
	public Coupon addCoupon(Coupon coupon) throws Exception{
		iCouponRepository.saveAndFlush(coupon);
		return coupon;
	}

	@Override
	public Coupon editCoupon(Coupon coupon) throws CouponNotFound{
		Coupon  bean = null;
		try {
			bean = iCouponRepository.findById(coupon.getCouponId()).get();
		}
		catch(Exception e) {
			throw new CouponNotFound("Coupon details not found!");
		}
		iCouponRepository.saveAndFlush(coupon);
		return bean;
	}

	@Override
	public Coupon deleteCoupon(Coupon coupon) throws CouponNotFound{
		Coupon  bean = null;
		try {
			bean = iCouponRepository.findById(coupon.getCouponId()).get();
		}
		catch(Exception e) {
			throw new CouponNotFound("Coupon details not found!");
		}
		iCouponRepository.deleteById(coupon.getCouponId());
		return bean;
	}

	@Override
	public List<Coupon> viewCoupons() throws Exception{
		return iCouponRepository.findAll();
	}

}
