package com.cg.pizzaorder.exception;

public class OrderAlreadyExistsException extends Exception{
	public OrderAlreadyExistsException(String str) {
		super(str);
	}
}
