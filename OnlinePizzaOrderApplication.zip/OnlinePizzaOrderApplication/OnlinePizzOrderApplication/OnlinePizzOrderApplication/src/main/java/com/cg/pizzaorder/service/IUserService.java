package com.cg.pizzaorder.service;

import java.util.List;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.User;
import com.cg.pizzaorder.exception.CouponNotFound;

public interface IUserService {
	
	public User addNewUser(User user) throws Exception;
	public User signIn(User user) throws Exception;
	public User signOut(User user) throws Exception;
	public User forgotPassword(String oldPassrod, String newPassword, int userId) throws Exception;

}
