package com.cg.pizzaorder.exception;

public class PizzaCreationException  extends Exception{
	public PizzaCreationException(String str) {
		super(str);
	}
}
