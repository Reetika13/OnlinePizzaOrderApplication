package com.cg.pizzaorder.service;

import java.util.List;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.exception.CouponNotFound;

public interface ICouponService {
	
	public Coupon addCoupon(Coupon coupon) throws Exception;
	public Coupon updateCoupon(Coupon coupon, int couponId) throws CouponNotFound;
	public Coupon deleteCoupon(Coupon coupon, int couponId) throws CouponNotFound;
	public List<Coupon> viewCoupons() throws Exception;
	

}