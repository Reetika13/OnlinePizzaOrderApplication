package com.cg.pizzaorder.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*
 
  {
  	"couponName" : "Coupon 1",
  	"couponType" : "Large Pizza Coupon",
  	"couponDescription" : "This coupon is for large pizzas only"
  }
  
 */

@Entity
public class Coupon {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int couponId;
	private String couponName;
	private String couponType;
	private String couponDescription;
	
	//@ManyToOne(fetch = FetchType.LAZY )
	//@JoinColumn(name = "pizza_id", referencedColumnName = "pizzaId")
	// Pizza pizza;

	public Coupon() {
		super();
	}

	public Coupon(int couponId, String couponName, String couponType, String couponDescription) {
		super();
		this.couponId = couponId;
		this.couponName = couponName;
		this.couponType = couponType;
		this.couponDescription = couponDescription;
		//this.pizza = pizza;
	}

	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

	public String getCouponDescription() {
		return couponDescription;
	}

	public void setCouponDescription(String couponDescription) {
		this.couponDescription = couponDescription;
	}

	/*public Pizza getPizza() {
	    return pizza;
	}

	public void setPizza(Pizza pizza) {
		this.pizza = pizza;
	}*/
	
	
	
	
	
}
