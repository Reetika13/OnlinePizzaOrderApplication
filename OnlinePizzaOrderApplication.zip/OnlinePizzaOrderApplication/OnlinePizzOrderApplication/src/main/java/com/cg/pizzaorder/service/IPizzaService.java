package com.cg.pizzaorder.service;



import java.util.List;

import com.cg.pizzaorder.entity.Pizza;

public interface IPizzaService {

	public Pizza addPizza(Pizza pizza) throws Exception;
	public Pizza updatePizza(Pizza pizza) throws Exception;
	public Pizza deletePizza(int pizzaId) throws Exception;
	public List<Pizza> viewPizzalist() throws Exception;
	public Pizza viewPizza(int pizzaId) throws Exception;
	public List<Pizza> viewPizzalist(double minCost , double maxCost) throws Exception;
	public List<Pizza> viewPizzalist(String pizzaType) throws Exception;
	

}