package com.cg.pizzaorder.service.impl;


import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.Order;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.repository.ICustomerRepository;
import com.cg.pizzaorder.repository.IOrderRepository;
import com.cg.pizzaorder.repository.IPizzaOrderRepository;
import com.cg.pizzaorder.service.IPizzaOrderService;
@Service("IPizzaOrderService")
public class IPizzaOrderServiceImpl implements IPizzaOrderService{
	
	@Autowired
	IPizzaOrderRepository iPizzaOrderRepository;
	@Autowired
ICustomerRepository custRepo;
	@Autowired
	IOrderRepository ordRepo;
	@Override
	public PizzaOrder bookPizzaOrder(PizzaOrder order) throws Exception {
		Customer c=custRepo.findById(order.getCustomer().getCustomerId()).get();
		order.setCustomer(c);
	//	iPizzaOrderRepository.saveAndFlush(order);
		Order o=ordRepo.findById(order.getOrder().getOrderId()).get();
		order.setOrder(o);
		iPizzaOrderRepository.saveAndFlush(order);
		return order;
	}
	
	@Override
	public PizzaOrder updatePizzaOrder(PizzaOrder order) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(order.getBookingOrderId()).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		iPizzaOrderRepository.saveAndFlush(order);
		return bean;
	}

	@Override
	public PizzaOrder cancelPizzaOrder(int bookingOrderId) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(bookingOrderId).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		iPizzaOrderRepository.deleteById(bookingOrderId);
		return bean;
	}

	@Override
	public PizzaOrder viewPizzaOrder(int bookingOrderId) throws Exception {
		PizzaOrder  bean = null;
		try {
			bean = iPizzaOrderRepository.findById(bookingOrderId).get();
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		return bean;
	}

	@Override
	public List<PizzaOrder> viewOrdersList() throws Exception {
		return iPizzaOrderRepository.findAll();
	}

	@Override
	public List<PizzaOrder> viewOrdersList(String date) throws Exception {
		List<PizzaOrder> ans = new ArrayList<PizzaOrder>();
		Date d = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
	    d = formatter.parse(date);
	    
		System.out.println("finding the order ....."+date);
		ans=iPizzaOrderRepository.searchByDate(d);
		
		return ans;
	}

	@Override
	public List<PizzaOrder> calculateTotal(String size, int quantity) throws Exception {
		List<PizzaOrder> ans = new ArrayList<PizzaOrder>();
		try {
			for(PizzaOrder i : iPizzaOrderRepository.findAll()) {
				if(i.getSize().equals(size) && i.getQuantity() == quantity) {
					ans.add(i);
				}
			}
		}
		catch(Exception e) {
			throw new Exception("Pizza Order details not found!");
		}
		return ans;
	}
	

}
