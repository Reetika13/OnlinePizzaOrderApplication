package com.cg.pizzaorder.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

/*
  JSON Data
  
  {
	"orderDate" : "2023-02-02",
	"transactionMode" : "Online",
	"quantity" : 10,
	"size" : "Large",
	"totalCost" : 550,
	"paymentMode" : "Debitcard",
	"customer" :{
		"customerName" : "Sreeja",
		"customerMobile" : "883989389",
		"customerEmail" : "sreeja@gmail.com",
		"customerAddress" : "Vizag",
		"userName" : "sre_09",
		"password" : "Sreeja@123"
	},
	"order" : {
		"orderType" : "Pizza Large",
		"orderDescription" : "Double cheeze margareeta"
	}
}
 */

@Entity
public class PizzaOrder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingOrderId;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd") 
	private LocalDate orderDate;
	
	private String transactionMode;
	private int quantity;
	private String size;
	private double totalCost;
	
	private String paymentMode; //CreditCard, Debitcard, Upi, bhmi, paytm
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id", referencedColumnName = "customerId")
	private Customer customer;

	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_id", referencedColumnName = "orderId")
	private Order order;

	public PizzaOrder() {
		super();
	}

	public PizzaOrder(int bookingOrderId, LocalDate orderDate, String transactionMode, int quantity, String size,
			double totalCost, String paymentMode, 
			Customer customer, Order order) {
		super();
		this.bookingOrderId = bookingOrderId;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.size = size;
		this.totalCost = totalCost;
		this.paymentMode = paymentMode;
		//this.pizzas = pizzas;
		this.customer = customer;
		//this.order = order;
	}

	public int getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(int bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	

}
