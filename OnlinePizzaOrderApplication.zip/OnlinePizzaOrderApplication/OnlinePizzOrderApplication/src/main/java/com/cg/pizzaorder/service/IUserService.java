package com.cg.pizzaorder.service;

import java.util.List;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.User;
import com.cg.pizzaorder.exception.CouponNotFound;

public interface IUserService {
	
	public User addNewUser(User user) throws Exception;
	public String signIn(User user) throws Exception;
	public String signOut(User user) throws Exception;
	public User forgotPassword(String oldPassword, String newPassword, int userId) throws Exception;

}
