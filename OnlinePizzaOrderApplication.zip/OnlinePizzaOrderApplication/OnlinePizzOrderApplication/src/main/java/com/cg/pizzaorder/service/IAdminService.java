package com.cg.pizzaorder.service;
import java.util.List;

import com.cg.pizzaorder.entity.Admin;



public interface IAdminService {
	public Admin addAdmin(Admin admin) ;
	public  Admin updateAdmin(Admin admin,int adminId) ;
	public List<Admin> viewAdmin();
}