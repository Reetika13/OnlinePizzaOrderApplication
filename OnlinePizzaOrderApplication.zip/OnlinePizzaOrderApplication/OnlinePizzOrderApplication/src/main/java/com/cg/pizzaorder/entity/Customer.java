
package com.cg.pizzaorder.entity;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
/*
{
    "customerName" : "Sreeja",
    "customerMobile" : "883989389",
    "customerEmail" : "sreeja@gmail.com",
    "customerAddress" : "Vizag",
    "userName" : "sre_09",
    "password" : "Sreeja@123"
}
*/
@Entity
public class Customer {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int customerId;
 private String customerName;
 private long customerMobile;
 private String customerEmail;
 private String customerAddress;
//    private String userName;
private String password;
 @OneToMany(mappedBy = "customer" , fetch = FetchType.EAGER)
 @Fetch(value = FetchMode.SUBSELECT)
 private List<PizzaOrder> pizzaOrder;
 public Customer() {
super();
 }
 
 public Customer(int customerId, String customerName, long customerMobile, String customerEmail, String customerAddress,
		String password, List<PizzaOrder> pizzaOrder) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerMobile = customerMobile;
	this.customerEmail = customerEmail;
	this.customerAddress = customerAddress;
	this.password = password;
 }

public int getCustomerId() {
 return customerId;
 }
 public void setCustomerId(int customerId) {
 this.customerId = customerId;
 }
 public String getCustomerName() {
 return customerName;
 }
 public void setCustomerName(String customerName) {
 this.customerName = customerName;
 }
 public long getCustomerMobile() {
 return customerMobile;
 }
 public void setCustomerMobile(long customerMobile) {
this.customerMobile = customerMobile;
 }
 public String getCustomerEmail() {
 return customerEmail;
}
  public void setCustomerEmail(String customerEmail) {
 this.customerEmail = customerEmail;
 }
  public String getCustomerAddress() {
 return customerAddress;
  }
  public void setCustomerAddress(String customerAddress) {
 this.customerAddress = customerAddress;
  }

  //    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    } 
  public String getPassword() {
	  return password;
 }
  public void setPassword(String password) {
	  this.password = password;
  }

  /*    public List<PizzaOrder> getPizzaOrder() {
        return pizzaOrder;
    }     public void setPizzaOrder(List<PizzaOrder> pizzaOrder) {
        this.pizzaOrder = pizzaOrder;
    } //    public User getUser() {
        return user;
 }  */
}

