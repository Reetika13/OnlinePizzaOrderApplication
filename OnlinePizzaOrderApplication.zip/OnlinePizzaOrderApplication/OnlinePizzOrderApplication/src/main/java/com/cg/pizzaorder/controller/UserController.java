package com.cg.pizzaorder.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;

import com.cg.pizzaorder.service.IUserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.pizzaorder.entity.Pizza;
import com.cg.pizzaorder.entity.User;
import com.cg.pizzaorder.service.IPizzaService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/odo-user")
public class UserController {
	
	@Autowired
	IUserService iUserService;
	
	@PostMapping("/addNewUser")
	public User addNewUser(@RequestBody User user) throws Exception{
		return iUserService.addNewUser(user);
	}
	
	@PostMapping("/signIn")
	public String signIn(@RequestBody User user) throws Exception{
		return "User signedIn";
	}
	
	@PostMapping("/signOut")
	public String signOut(@RequestBody User user) throws Exception{
		return "User Signed Out";
	}
	
	@PostMapping("/forgotPassword/{oldPassword}/{newPassword}/{userId}")
	public User forgotPassword(@RequestBody String oldPassword, String newPassword, int userId) throws Exception{
		return iUserService.forgotPassword(oldPassword, newPassword, userId);
	}

}
