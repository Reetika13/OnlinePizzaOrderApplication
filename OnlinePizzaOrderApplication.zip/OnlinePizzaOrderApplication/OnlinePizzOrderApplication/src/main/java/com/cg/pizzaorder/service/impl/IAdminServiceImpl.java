package com.cg.pizzaorder.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizzaorder.entity.Admin;

import com.cg.pizzaorder.repository.IAdminRepository;

import com.cg.pizzaorder.service.IAdminService;
@Component
public class IAdminServiceImpl implements IAdminService{
	@Autowired
	private IAdminRepository adminRepository;
	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		  admin = adminRepository.save(admin);
		 return admin;
		
	}
	@Override
	public Admin updateAdmin(Admin admin,int adminId) {
		// TODO Auto-generated method stub
		Admin admin1=adminRepository.findById(admin.getAdminId()).get();
		admin1.setAdminUserName(admin.getAdminUserName());
		admin1.setAdminPassword(admin.getAdminPassword());
		adminRepository.save(admin1);
		return admin1;
		
	}
	@Override
	public List<Admin> viewAdmin() {
		// TODO Auto-generated method stub
		 List<Admin> AdminList=	adminRepository.findAll();
			return  AdminList;
		
	}
}
