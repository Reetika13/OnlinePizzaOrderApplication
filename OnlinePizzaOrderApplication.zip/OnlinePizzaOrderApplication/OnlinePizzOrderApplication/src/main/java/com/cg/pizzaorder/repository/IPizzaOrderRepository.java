package com.cg.pizzaorder.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.pizzaorder.entity.PizzaOrder;

@Repository
public interface IPizzaOrderRepository  extends JpaRepository<PizzaOrder, Integer> {

	@Query(value = "select * from pizza_order where order_date= :d", nativeQuery = true )
	List<PizzaOrder> searchByDate(@Param("d") Date date);
}
