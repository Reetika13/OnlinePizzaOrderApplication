package com.cg.pizzaorder.service.impl;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.Pizza;
import com.cg.pizzaorder.entity.PizzaOrder;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.repository.IPizzaRepository;
import com.cg.pizzaorder.service.IPizzaService;

@Service("IPizzaService")
public class IPizzaServiceImpl implements IPizzaService{
	
	@Autowired
	IPizzaRepository iPizzaRepository;
	
	@Override
	public Pizza addPizza(Pizza pizza) throws Exception {
		iPizzaRepository.save(pizza);
		return pizza;
	}

	@Override
	public Pizza updatePizza(Pizza pizza) throws Exception {
		Pizza  bean = null;
		try {
			bean = iPizzaRepository.findById(pizza.getPizzaId()).get();
		}
		catch(Exception e) {
			throw new CouponNotFound("Pizza details not found!");
		}
		iPizzaRepository.save(pizza);
		return bean;
	}

	@Override
	public Pizza deletePizza(int pizzaId) throws Exception {
		Pizza  bean = null;
		try {
			bean = iPizzaRepository.findById(pizzaId).get();
		}
		catch(Exception e) {
			throw new CouponNotFound("Pizza details not found!");
		}
		iPizzaRepository.deleteById(pizzaId);
		return bean;
	}

	@Override
	public List<Pizza> viewPizzalist() throws Exception {
		return iPizzaRepository.findAll();
	}

	@Override
	public Pizza viewPizza(int pizzaId) throws Exception {
		Pizza  bean = null;
		try {
			bean = iPizzaRepository.findById(pizzaId).get();
		}
		catch(Exception e) {
			throw new CouponNotFound("Pizza details not found!");
		}
		return bean;
	}

	@Override
	public List<Pizza> viewPizzalist(double minCost, double maxCost) throws Exception {
		List<Pizza> ans = new ArrayList<Pizza>();
		try {
			for(Pizza i : iPizzaRepository.findAll()) {
				if(i.getPizzaCost()>=minCost && i.getPizzaCost()<=maxCost) {
					ans.add(i);
				}
			}
		}
		catch(Exception e) {
			throw new Exception("Pizza details not found!");
		}
		return ans;
	}

	@Override
	public List<Pizza> viewPizzalist(String pizzaType) throws Exception {
		List<Pizza> ans = new ArrayList<Pizza>();
		try {
			for(Pizza i : iPizzaRepository.findAll()) {
				if(i.getPizzaType().equals(pizzaType)) {
					ans.add(i);
				}
			}
		}
		catch(Exception e) {
			throw new Exception("Pizza details not found!");
		}
		return ans;
	}


}