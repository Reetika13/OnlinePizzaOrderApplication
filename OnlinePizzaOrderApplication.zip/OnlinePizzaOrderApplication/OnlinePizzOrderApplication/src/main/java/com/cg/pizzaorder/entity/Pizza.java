package com.cg.pizzaorder.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Pizza {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private int pizzaId;
private String pizzaType;
private String pizzaName;
private String pizzaDescription;
private double pizzaCost;
private double pizzaCostAfterCoupon;
private String toppings;




public Pizza() {
	super();
}

public Pizza(int pizzaId, String pizzaName, String pizzaType, String pizzaDescription, double pizzaCost,
		double pizzaCostAfterCoupon, String toppings) {
	super();
	this.pizzaId = pizzaId;
	this.pizzaName = pizzaName;
	this.pizzaType = pizzaType;
	this.pizzaDescription = pizzaDescription;
	this.pizzaCost = pizzaCost;
	this.pizzaCostAfterCoupon = pizzaCostAfterCoupon;
	
	this.toppings = toppings;
	//this.pizzaOrder = pizzaorder;
}

public int getPizzaId() {
	return pizzaId;
}
public void setPizzaId(int pizzaId) {
	this.pizzaId = pizzaId;
}
public String getPizzaType() {
	return pizzaType;
}
public void setPizzaType(String pizzaType) {
	this.pizzaType = pizzaType;
}
public String getPizzaName() {
	return pizzaName;
}
public void setPizzaName(String pizzaName) {
	this.pizzaName = pizzaName;
}
public String getPizzaDescription() {
	return pizzaDescription;
}
public void setPizzaDescription(String pizzaDescription) {
	this.pizzaDescription = pizzaDescription;
}
public double getPizzaCost() {
	return pizzaCost;
}
public void setPizzaCost(double pizzaCost) {
	this.pizzaCost = pizzaCost;
}
public double getPizzaCostAfterCoupon() {
	return pizzaCostAfterCoupon;
}
public void setPizzaCostAfterCoupon(double pizzaCostAfterCoupon) {
	this.pizzaCostAfterCoupon = pizzaCostAfterCoupon;
}

public String getToppings() {
	return toppings;
}

public void setToppings(String toppings) {
	this.toppings = toppings;
}
}