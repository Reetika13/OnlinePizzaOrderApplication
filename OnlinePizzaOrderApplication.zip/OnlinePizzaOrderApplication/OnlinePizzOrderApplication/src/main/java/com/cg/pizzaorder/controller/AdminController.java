package com.cg.pizzaorder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizzaorder.entity.Admin;
import com.cg.pizzaorder.service.IAdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	
		
		@Autowired
		IAdminService adminService;
		
		@PostMapping 
		public Admin addAdmin(@RequestBody Admin admin) {
			return adminService.addAdmin(admin);
		}
		
		@PutMapping("/updateAdmin/{adminId}" )
		public Admin updateAdmin(@RequestBody Admin admin,@PathVariable("adminId") int adminId) {
			return adminService.updateAdmin(admin, adminId);
		}
		
		@GetMapping("/viewAdmin")
		public List<Admin> viewAdmin() {
			return adminService.viewAdmin();
		}
}
