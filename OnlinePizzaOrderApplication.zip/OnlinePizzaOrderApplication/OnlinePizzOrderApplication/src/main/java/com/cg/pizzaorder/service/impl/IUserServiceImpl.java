package com.cg.pizzaorder.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.Pizza;
import com.cg.pizzaorder.entity.User;
import com.cg.pizzaorder.repository.IUserRepository;
import com.cg.pizzaorder.service.IUserService;

@Service("IUserService")
public class IUserServiceImpl  implements IUserService{
	
	@Autowired
	IUserRepository iUserRepository;

	
	public User addNewUser(User user) throws Exception {
		iUserRepository.saveAndFlush(user);
		return user;
	}

	public String signIn(User user) throws Exception {
		User bean = null;
		try {
			for(User i: iUserRepository.findAll()) {
				if(i.getUserName().equals(user.getUserName())) {
					if(i.getPassword().equals(user.getPassword())){
						bean = i;
					}
				}
			}
		}
		catch(Exception e) {
			throw new Exception("User details not found");
		}
		return "User signedIn";
	}
	
	public String signOut(User user) throws Exception {
		User bean = null;
		try {
			for(User i: iUserRepository.findAll()) {
				if(i.getUserName().equals(user.getUserName())) {
					if(i.getPassword().equals(user.getPassword())){
						bean = i;
					}
				}
			}
		}
		catch(Exception e) {
			throw new Exception("User details not found");
		}
		return "User Signed Out";
	}

	public User forgotPassword(String oldPassrod, String newPassword, int userId) throws Exception {
		User  bean = null;
		try {
			bean = iUserRepository.findById(userId).get();
		}
		catch(Exception e) {
			throw new Exception("User details not found!");
		}
		bean.setPassword(newPassword);
		return bean;
	}

}
