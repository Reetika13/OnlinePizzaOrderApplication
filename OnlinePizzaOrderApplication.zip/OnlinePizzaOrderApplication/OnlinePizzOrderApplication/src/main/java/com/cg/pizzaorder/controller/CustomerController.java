package com.cg.pizzaorder.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.exception.CouponNotFound;
import com.cg.pizzaorder.service.ICouponService;
import com.cg.pizzaorder.service.ICustomerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/odo-customer")
public class CustomerController {
	
	@Autowired 
	ICustomerService iCustomerService;
	
	@PostMapping("/addCustomer")
	public Customer addCustomer(@RequestBody Customer customer) throws Exception{
		return iCustomerService.addCustomer(customer);
	}
	
	@PutMapping("/updateCustomer")
	public Customer updateCustomer(@RequestBody Customer customer) throws Exception{
		return iCustomerService.updateCustomer(customer);
	}
	
	//public Customer deleteCustomer(Customer customer) throws Exception;
	
	@GetMapping("/viewCustomers")
	public List<Customer> viewCustomers() throws Exception{
		return iCustomerService.viewCustomers();
	}
	
	@GetMapping("/viewCustomer/{customerId}")
	public Customer viewCustomer(@PathVariable @Valid int customerId) throws Exception{
		return iCustomerService.viewCustomer(customerId);
	}


}
