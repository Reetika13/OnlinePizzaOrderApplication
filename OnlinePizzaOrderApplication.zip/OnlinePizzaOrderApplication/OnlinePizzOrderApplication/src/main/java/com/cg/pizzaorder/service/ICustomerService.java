package com.cg.pizzaorder.service;

import java.util.List;

import com.cg.pizzaorder.entity.Coupon;
import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.exception.CouponNotFound;

public interface ICustomerService {
	
	public Customer addCustomer(Customer customer) throws Exception;
	public Customer updateCustomer(Customer customer) throws Exception;
	//public Customer deleteCustomer(Customer customer,int customerId) throws Exception;
	public List<Customer> viewCustomers() throws Exception;
	public Customer viewCustomer(int customerId) throws Exception;
}
